#pragma once
int run_script(const char *file);
