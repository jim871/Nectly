#pragma once
void random_init(float *arr, int n);
